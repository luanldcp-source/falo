const CACHE = "falo-static-v2";

function scopeUrl(path) {
  return new URL(path, self.registration.scope).href;
}

self.addEventListener("install", (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE).then((cache) =>
      cache
        .addAll([
          scopeUrl("./"),
          scopeUrl("index.html"),
          scopeUrl("manifest.webmanifest"),
          scopeUrl("icons/icon-192.png"),
          scopeUrl("icons/icon-512.png"),
          scopeUrl("icons/icon-maskable-512.png"),
          scopeUrl("icons/apple-touch-icon.png"),
        ])
        .catch(() => undefined),
    ),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (!url.href.startsWith(self.registration.scope)) return;

  event.respondWith(
    (async () => {
      if (request.mode === "navigate") {
        try {
          const fresh = await fetch(request);
          const cache = await caches.open(CACHE);
          cache.put(request, fresh.clone()).catch(() => undefined);
          return fresh;
        } catch {
          return (
            (await caches.match(request)) ||
            (await caches.match(scopeUrl("index.html"))) ||
            (await caches.match(scopeUrl("./"))) ||
            new Response("Sem conexão. Abra o Falô de novo quando a rede voltar.", {
              status: 503,
              headers: { "Content-Type": "text/plain; charset=utf-8" },
            })
          );
        }
      }

      const cached = await caches.match(request);
      if (cached) return cached;
      try {
        const fresh = await fetch(request);
        if (fresh.ok) {
          const cache = await caches.open(CACHE);
          cache.put(request, fresh.clone()).catch(() => undefined);
        }
        return fresh;
      } catch {
        return new Response("", { status: 504 });
      }
    })(),
  );
});
